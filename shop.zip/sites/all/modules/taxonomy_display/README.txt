Visit the documentation for the project at http://drupal.org/node/1254876 for
details on how to use the module.